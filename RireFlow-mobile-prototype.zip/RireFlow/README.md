# RireFlow — maquette mobile fonctionnelle

Prototype Expo/React Native d'une application de vidéos comiques courtes.

## Lancer

```bash
npm install
npx expo start
```

Puis ouvrir avec Expo Go sur Android/iOS ou un simulateur.

## Ce qui est inclus

- Feed vertical plein écran avec lecture automatique et swipe
- Likes, commentaires, partage, enregistrement
- Bouton « Encore une »
- Découverte, recherche et filtres humoristiques
- Publication simulée avec import vidéo depuis le téléphone
- Notifications
- Profil utilisateur et onglets vidéos/aimées/enregistrées/historique
- Profils/créateurs fictifs
- États vide et interactions de démonstration
- Identité RireFlow originale orange/rose/jaune/bleu clair/noir
- Données fictives et vidéos de démonstration

## Pour une version production

Ajouter une API/backend, authentification Apple/Google/e-mail, stockage vidéo, transcodage, CDN, recommandations serveur, vraie modération, signalement, notifications push, analytics et base de données.