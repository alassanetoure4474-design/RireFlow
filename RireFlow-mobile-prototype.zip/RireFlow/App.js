import React, { useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, StyleSheet, Pressable, FlatList,
  Image, TextInput, Alert, Modal, Share, StatusBar
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { VideoView, useVideoPlayer } from "expo-video";
import * as ImagePicker from "expo-image-picker";

const COLORS = {
  orange: "#FF8A3D",
  pink: "#FF4F81",
  yellow: "#FFD84D",
  blue: "#79D7FF",
  black: "#111111",
  white: "#FFFFFF",
  soft: "#F7F7F4",
  muted: "#777777",
  border: "#E8E8E8"
};

const VIDEOS = [
  {
    id: "1",
    title: "Quand ton pote dit « j'arrive dans 5 minutes » 😂",
    creator: "MomoRire",
    handle: "@momorire",
    category: "Sketchs",
    avatar: "https://i.pravatar.cc/150?img=12",
    video: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    likes: 18400,
    comments: 421,
    tags: ["potes", "quotidien", "sketch"]
  },
  {
    id: "2",
    title: "Le fail cuisine que personne n'avait prévu 🍳",
    creator: "Léa LOL",
    handle: "@lealol",
    category: "Fails",
    avatar: "https://i.pravatar.cc/150?img=47",
    video: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    likes: 12600,
    comments: 208,
    tags: ["fail", "cuisine"]
  },
  {
    id: "3",
    title: "POV : ton cerveau à 3h du matin",
    creator: "Kévin Impro",
    handle: "@kevinimpro",
    category: "Improvisation",
    avatar: "https://i.pravatar.cc/150?img=33",
    video: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    likes: 31200,
    comments: 799,
    tags: ["pov", "absurde", "nuit"]
  }
];

const CATEGORIES = ["Tous", "Sketchs", "Fails", "Humour absurde", "Parodies", "Improvisation", "Familial"];

function formatCount(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + " M";
  if (n >= 1000) return (n / 1000).toFixed(1) + " k";
  return String(n);
}

function Logo() {
  return (
    <View style={styles.logoRow}>
      <View style={styles.logoMark}><Text style={styles.logoFace}>😄</Text></View>
      <Text style={styles.logoText}>Rire<Text style={{color: COLORS.orange}}>Flow</Text></Text>
    </View>
  );
}

function VideoCard({ item, active, liked, saved, onLike, onSave, onComment }) {
  const player = useVideoPlayer(item.video, p => {
    p.loop = true;
    if (active) p.play();
  });

  React.useEffect(() => {
    if (active) player.play();
    else player.pause();
  }, [active]);

  return (
    <View style={styles.videoPage}>
      <VideoView player={player} style={StyleSheet.absoluteFill} contentFit="cover" nativeControls={false} />
      <View style={styles.videoShade} />
      <View style={styles.videoTop}>
        <Logo />
        <Pressable style={styles.roundButton} onPress={() => Alert.alert("Mode son", "Son activé / désactivé (démo).")}>
          <Ionicons name="volume-high" size={21} color="#fff" />
        </Pressable>
      </View>

      <View style={styles.videoBottom}>
        <View style={{flex: 1, paddingRight: 70}}>
          <View style={styles.creatorLine}>
            <Image source={{uri: item.avatar}} style={styles.avatar} />
            <View>
              <Text style={styles.creator}>{item.creator}</Text>
              <Text style={styles.handle}>{item.handle} · {item.category}</Text>
            </View>
          </View>
          <Text style={styles.videoTitle}>{item.title}</Text>
          <Text style={styles.tags}>{item.tags.map(t => "#" + t).join("  ")}</Text>
          <Pressable style={styles.moreButton} onPress={() => Alert.alert("Encore une", "Nouvelle vidéo recommandée selon tes goûts.")}>
            <Text style={styles.moreButtonText}>✨ Encore une</Text>
          </Pressable>
        </View>

        <View style={styles.actions}>
          <Pressable onPress={onLike} style={styles.action}>
            <View style={[styles.actionCircle, liked && styles.actionActive]}>
              <Ionicons name={liked ? "heart" : "heart-outline"} size={25} color={liked ? COLORS.pink : "#fff"} />
            </View>
            <Text style={styles.actionText}>{formatCount(item.likes + (liked ? 1 : 0))}</Text>
          </Pressable>
          <Pressable onPress={onComment} style={styles.action}>
            <View style={styles.actionCircle}><Ionicons name="chatbubble-ellipses-outline" size={24} color="#fff" /></View>
            <Text style={styles.actionText}>{formatCount(item.comments)}</Text>
          </Pressable>
          <Pressable onPress={() => Share.share({message: `Regarde cette vidéo sur RireFlow : ${item.title}`})} style={styles.action}>
            <View style={styles.actionCircle}><Ionicons name="paper-plane-outline" size={24} color="#fff" /></View>
            <Text style={styles.actionText}>Partager</Text>
          </Pressable>
          <Pressable onPress={onSave} style={styles.action}>
            <View style={[styles.actionCircle, saved && styles.actionActive]}><Ionicons name={saved ? "bookmark" : "bookmark-outline"} size={24} color={saved ? COLORS.yellow : "#fff"} /></View>
            <Text style={styles.actionText}>Garder</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

export default function App() {
  const [tab, setTab] = useState("Accueil");
  const [index, setIndex] = useState(0);
  const [liked, setLiked] = useState({});
  const [saved, setSaved] = useState({});
  const [commentsFor, setCommentsFor] = useState(null);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("Tous");
  const [profileTab, setProfileTab] = useState("Vidéos");
  const [selectedFile, setSelectedFile] = useState(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return VIDEOS.filter(v => {
      const matchesCat = category === "Tous" || v.category === category;
      const matchesSearch = !q || [v.title, v.creator, v.category, ...v.tags].join(" ").toLowerCase().includes(q);
      return matchesCat && matchesSearch;
    });
  }, [search, category]);

  const toggleLike = id => setLiked(x => ({...x, [id]: !x[id]}));
  const toggleSave = id => setSaved(x => ({...x, [id]: !x[id]}));

  const pickVideo = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["videos"],
      allowsEditing: false,
      quality: 1
    });
    if (!result.canceled) setSelectedFile(result.assets[0].uri);
  };

  const renderFeed = () => (
    <View style={{flex: 1, backgroundColor: "#000"}}>
      <FlatList
        data={VIDEOS}
        keyExtractor={x => x.id}
        pagingEnabled
        showsVerticalScrollIndicator={false}
        onMomentumScrollEnd={e => setIndex(Math.round(e.nativeEvent.contentOffset.y / e.nativeEvent.layoutMeasurement.height))}
        renderItem={({item, index: i}) => (
          <VideoCard
            item={item}
            active={i === index}
            liked={!!liked[item.id]}
            saved={!!saved[item.id]}
            onLike={() => toggleLike(item.id)}
            onSave={() => toggleSave(item.id)}
            onComment={() => setCommentsFor(item)}
          />
        )}
      />
    </View>
  );

  const renderDiscover = () => (
    <SafeAreaView style={styles.screen}>
      <View style={styles.header}><Logo /><Text style={styles.headerTitle}>Découvrir</Text></View>
      <View style={styles.searchBox}>
        <Ionicons name="search" size={20} color={COLORS.muted}/>
        <TextInput value={search} onChangeText={setSearch} placeholder="Vidéos, créateurs, humour..." style={styles.searchInput}/>
      </View>
      <FlatList
        horizontal data={CATEGORIES} showsHorizontalScrollIndicator={false}
        contentContainerStyle={{paddingHorizontal: 16, gap: 8, paddingBottom: 14}}
        renderItem={({item}) => <Pressable onPress={() => setCategory(item)} style={[styles.chip, category === item && styles.chipActive]}><Text style={[styles.chipText, category === item && {color:"#fff"}]}>{item}</Text></Pressable>}
        keyExtractor={x => x}
      />
      <Text style={styles.sectionTitle}>Pour toi</Text>
      <FlatList
        data={filtered}
        numColumns={2}
        keyExtractor={x => x.id}
        contentContainerStyle={{padding: 12}}
        renderItem={({item}) => (
          <Pressable style={styles.gridCard} onPress={() => {setIndex(VIDEOS.findIndex(v => v.id === item.id)); setTab("Accueil")}}>
            <Image source={{uri: item.avatar}} style={styles.gridImage}/>
            <View style={styles.gridOverlay}><Text style={styles.gridPlay}>▶</Text></View>
            <View style={styles.gridInfo}><Text style={styles.gridTitle} numberOfLines={2}>{item.title}</Text><Text style={styles.gridCreator}>{item.creator}</Text></View>
          </Pressable>
        )}
        ListEmptyComponent={<View style={styles.empty}><Text style={{fontSize:42}}>😶</Text><Text style={styles.emptyTitle}>Rien ici pour le moment</Text><Text style={styles.emptyText}>Essaie un autre mot ou une autre catégorie.</Text></View>}
      />
    </SafeAreaView>
  );

  const renderPublish = () => (
    <SafeAreaView style={styles.screen}>
      <View style={styles.header}><Logo /><Text style={styles.headerTitle}>Publier</Text></View>
      <View style={styles.publishBox}>
        <View style={styles.publishIcon}><Ionicons name="videocam" size={42} color={COLORS.orange}/></View>
        <Text style={styles.publishTitle}>{selectedFile ? "Vidéo sélectionnée 🎉" : "Partage ton moment drôle"}</Text>
        <Text style={styles.publishText}>Importe une vidéo depuis ton téléphone. La publication est simulée dans cette maquette.</Text>
        <Pressable style={styles.primaryButton} onPress={pickVideo}><Ionicons name="images-outline" size={20} color="#fff"/><Text style={styles.primaryButtonText}>Importer une vidéo</Text></Pressable>
        <Pressable style={styles.secondaryButton} onPress={() => Alert.alert("Caméra", "La caméra sera ouverte dans la version production.")}><Ionicons name="camera-outline" size={20} color={COLORS.black}/><Text style={styles.secondaryButtonText}>Enregistrer avec la caméra</Text></Pressable>
        {selectedFile && <Pressable style={styles.primaryButton} onPress={() => Alert.alert("Publication", "Ta vidéo a été publiée dans la démo !")}><Text style={styles.primaryButtonText}>Publier maintenant</Text></Pressable>}
        <Text style={styles.rules}>Respecte les règles RireFlow : pas de harcèlement, nudité sexuelle, violence graphique ou contenu illégal.</Text>
      </View>
    </SafeAreaView>
  );

  const renderNotifications = () => (
    <SafeAreaView style={styles.screen}>
      <View style={styles.header}><Logo /><Text style={styles.headerTitle}>Notifications</Text></View>
      {[
        ["MomoRire", "a aimé ta dernière vidéo", "2 min", "❤️"],
        ["Léa LOL", "a commencé à te suivre", "18 min", "👋"],
        ["RireFlow", "Le défi comique de la semaine est lancé !", "1 h", "🔥"]
      ].map((n, i) => <View style={styles.notification} key={i}><Text style={{fontSize:28}}>{n[3]}</Text><View style={{flex:1}}><Text style={styles.notifText}><Text style={{fontWeight:"800"}}>{n[0]}</Text> {n[1]}</Text><Text style={styles.notifTime}>{n[2]}</Text></View></View>)}
    </SafeAreaView>
  );

  const renderProfile = () => (
    <SafeAreaView style={styles.screen}>
      <View style={styles.profileHero}>
        <Image source={{uri:"https://i.pravatar.cc/200?img=68"}} style={styles.profileAvatar}/>
        <Text style={styles.profileName}>Baki Rire</Text>
        <Text style={styles.profileBio}>Je viens pour rire, je reste pour les fails 😂</Text>
        <View style={styles.stats}><View><Text style={styles.statNum}>128</Text><Text style={styles.statLabel}>Abonnés</Text></View><View><Text style={styles.statNum}>46</Text><Text style={styles.statLabel}>Suivis</Text></View><View><Text style={styles.statNum}>24</Text><Text style={styles.statLabel}>Vidéos</Text></View></View>
      </View>
      <View style={styles.profileTabs}>{["Vidéos","Aimées","Enregistrées","Historique"].map(t => <Pressable key={t} onPress={() => setProfileTab(t)} style={[styles.profileTab, profileTab === t && styles.profileTabActive]}><Text style={[styles.profileTabText, profileTab === t && {color:COLORS.orange}]}>{t}</Text></Pressable>)}</View>
      <View style={styles.profileGrid}>{VIDEOS.map(v => <View style={styles.profileTile} key={v.id}><Image source={{uri:v.avatar}} style={{width:"100%",height:"100%"}}/><View style={styles.tileShade}><Text style={{color:"#fff",fontWeight:"800"}}>▶ {formatCount(v.likes)}</Text></View></View>)}</View>
    </SafeAreaView>
  );

  const renderTab = () => {
    if (tab === "Accueil") return renderFeed();
    if (tab === "Découvrir") return renderDiscover();
    if (tab === "Publier") return renderPublish();
    if (tab === "Notifications") return renderNotifications();
    return renderProfile();
  };

  return (
    <View style={{flex:1, backgroundColor: tab === "Accueil" ? "#000" : COLORS.soft}}>
      <StatusBar barStyle={tab === "Accueil" ? "light-content" : "dark-content"} />
      {renderTab()}
      <View style={styles.bottomNav}>
        {[
          ["Accueil","home-outline","home"],
          ["Découvrir","compass-outline","compass"],
          ["Publier","add-circle-outline","add-circle"],
          ["Notifications","notifications-outline","notifications"],
          ["Profil","person-outline","person"]
        ].map(([label,outline,filled]) => (
          <Pressable key={label} style={styles.navItem} onPress={() => setTab(label)}>
            <Ionicons name={tab === label ? filled : outline} size={25} color={tab === label ? COLORS.orange : "#777"} />
            <Text style={[styles.navLabel, tab === label && {color:COLORS.orange,fontWeight:"800"}]}>{label}</Text>
          </Pressable>
        ))}
      </View>

      <Modal visible={!!commentsFor} animationType="slide" transparent onRequestClose={() => setCommentsFor(null)}>
        <View style={styles.modalBackdrop}>
          <View style={styles.commentSheet}>
            <View style={styles.sheetHandle}/>
            <Text style={styles.commentTitle}>Commentaires</Text>
            <Text style={styles.comment}>😂 « C'est exactement mon frère ! » <Text style={styles.commentMeta}>@sarah • 2 min</Text></Text>
            <Text style={styles.comment}>Je pleure de rire 😭 <Text style={styles.commentMeta}>@moussa • 8 min</Text></Text>
            <Text style={styles.comment}>Encore une ! <Text style={styles.commentMeta}>@ines • 12 min</Text></Text>
            <Pressable style={styles.primaryButton} onPress={() => setCommentsFor(null)}><Text style={styles.primaryButtonText}>Fermer</Text></Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen:{flex:1,backgroundColor:COLORS.soft},
  header:{height:76,paddingHorizontal:18,flexDirection:"row",alignItems:"center",justifyContent:"space-between",backgroundColor:"#fff"},
  headerTitle:{fontSize:22,fontWeight:"900",color:COLORS.black},
  logoRow:{flexDirection:"row",alignItems:"center",gap:8},
  logoMark:{width:38,height:38,borderRadius:14,backgroundColor:COLORS.yellow,alignItems:"center",justifyContent:"center",transform:[{rotate:"-5deg"}]},
  logoFace:{fontSize:23},
  logoText:{fontSize:21,fontWeight:"900",color:COLORS.black},
  videoPage:{height:"100%",width:"100%",backgroundColor:"#000",position:"relative"},
  videoShade:{...StyleSheet.absoluteFillObject,backgroundColor:"rgba(0,0,0,0.20)"},
  videoTop:{position:"absolute",top:55,left:18,right:18,flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
  roundButton:{width:42,height:42,borderRadius:21,backgroundColor:"rgba(0,0,0,.35)",alignItems:"center",justifyContent:"center"},
  videoBottom:{position:"absolute",bottom:22,left:16,right:14,flexDirection:"row",alignItems:"flex-end"},
  creatorLine:{flexDirection:"row",alignItems:"center",gap:10,marginBottom:10},
  avatar:{width:42,height:42,borderRadius:21,borderWidth:2,borderColor:"#fff"},
  creator:{color:"#fff",fontSize:16,fontWeight:"900"},
  handle:{color:"#eee",fontSize:12,marginTop:2},
  videoTitle:{color:"#fff",fontSize:18,fontWeight:"800",lineHeight:24},
  tags:{color:"#fff",marginTop:8,fontWeight:"700"},
  moreButton:{alignSelf:"flex-start",marginTop:12,paddingHorizontal:15,paddingVertical:10,borderRadius:18,backgroundColor:COLORS.orange},
  moreButtonText:{color:"#fff",fontWeight:"900"},
  actions:{width:58,alignItems:"center",gap:13},
  action:{alignItems:"center"},
  actionCircle:{width:45,height:45,borderRadius:23,backgroundColor:"rgba(0,0,0,.38)",alignItems:"center",justifyContent:"center"},
  actionActive:{backgroundColor:"#fff"},
  actionText:{color:"#fff",fontSize:10,fontWeight:"800",marginTop:3},
  searchBox:{margin:14,backgroundColor:"#fff",borderRadius:16,paddingHorizontal:14,height:48,flexDirection:"row",alignItems:"center",borderWidth:1,borderColor:COLORS.border},
  searchInput:{flex:1,marginLeft:9,fontSize:15},
  chip:{paddingHorizontal:14,paddingVertical:9,borderRadius:20,backgroundColor:"#fff",borderWidth:1,borderColor:COLORS.border},
  chipActive:{backgroundColor:COLORS.orange,borderColor:COLORS.orange},
  chipText:{fontWeight:"700",color:COLORS.black},
  sectionTitle:{fontSize:22,fontWeight:"900",paddingHorizontal:16,paddingBottom:4},
  gridCard:{flex:1,margin:6,borderRadius:18,overflow:"hidden",backgroundColor:"#fff",minHeight:230},
  gridImage:{width:"100%",height:230,backgroundColor:"#ddd"},
  gridOverlay:{position:"absolute",top:10,right:10,width:38,height:38,borderRadius:19,backgroundColor:"rgba(0,0,0,.5)",alignItems:"center",justifyContent:"center"},
  gridPlay:{color:"#fff"},
  gridInfo:{position:"absolute",bottom:0,left:0,right:0,padding:10,backgroundColor:"rgba(0,0,0,.55)"},
  gridTitle:{color:"#fff",fontWeight:"800"},
  gridCreator:{color:"#ddd",fontSize:11,marginTop:3},
  empty:{alignItems:"center",justifyContent:"center",padding:50},
  emptyTitle:{fontSize:18,fontWeight:"900",marginTop:10},
  emptyText:{color:COLORS.muted,textAlign:"center",marginTop:5},
  publishBox:{margin:18,padding:22,borderRadius:24,backgroundColor:"#fff",alignItems:"center",borderWidth:1,borderColor:COLORS.border},
  publishIcon:{width:90,height:90,borderRadius:30,backgroundColor:"#FFF1E8",alignItems:"center",justifyContent:"center"},
  publishTitle:{fontSize:23,fontWeight:"900",marginTop:18,textAlign:"center"},
  publishText:{color:COLORS.muted,textAlign:"center",lineHeight:21,marginTop:8,marginBottom:18},
  primaryButton:{height:50,borderRadius:16,backgroundColor:COLORS.orange,flexDirection:"row",alignItems:"center",justifyContent:"center",gap:8,width:"100%",marginTop:10},
  primaryButtonText:{color:"#fff",fontWeight:"900",fontSize:15},
  secondaryButton:{height:50,borderRadius:16,backgroundColor:COLORS.yellow,flexDirection:"row",alignItems:"center",justifyContent:"center",gap:8,width:"100%",marginTop:10},
  secondaryButtonText:{fontWeight:"900",fontSize:14},
  rules:{fontSize:11,color:COLORS.muted,textAlign:"center",marginTop:16,lineHeight:17},
  notification:{marginHorizontal:14,marginTop:10,padding:15,borderRadius:18,backgroundColor:"#fff",flexDirection:"row",alignItems:"center",gap:12},
  notifText:{fontSize:14,lineHeight:20},
  notifTime:{color:COLORS.muted,fontSize:11,marginTop:3},
  profileHero:{backgroundColor:"#fff",alignItems:"center",paddingTop:28,paddingBottom:22},
  profileAvatar:{width:88,height:88,borderRadius:44,borderWidth:4,borderColor:COLORS.yellow},
  profileName:{fontSize:24,fontWeight:"900",marginTop:9},
  profileBio:{color:COLORS.muted,marginTop:4},
  stats:{flexDirection:"row",gap:42,marginTop:18},
  statNum:{fontSize:19,fontWeight:"900",textAlign:"center"},
  statLabel:{fontSize:11,color:COLORS.muted,textAlign:"center",marginTop:2},
  profileTabs:{height:52,backgroundColor:"#fff",flexDirection:"row",borderTopWidth:1,borderColor:COLORS.border},
  profileTab:{flex:1,alignItems:"center",justifyContent:"center"},
  profileTabActive:{borderBottomWidth:3,borderBottomColor:COLORS.orange},
  profileTabText:{fontSize:11,fontWeight:"800",color:COLORS.muted},
  profileGrid:{flexDirection:"row",flexWrap:"wrap",padding:6,gap:6},
  profileTile:{width:"31.8%",aspectRatio:0.75,borderRadius:12,overflow:"hidden",backgroundColor:"#ddd"},
  tileShade:{position:"absolute",left:0,right:0,bottom:0,padding:7,backgroundColor:"rgba(0,0,0,.45)"},
  bottomNav:{height:76,backgroundColor:"#fff",borderTopWidth:1,borderColor:COLORS.border,flexDirection:"row",paddingBottom:8},
  navItem:{flex:1,alignItems:"center",justifyContent:"center",gap:3},
  navLabel:{fontSize:10,color:"#777"},
  modalBackdrop:{flex:1,backgroundColor:"rgba(0,0,0,.45)",justifyContent:"flex-end"},
  commentSheet:{backgroundColor:"#fff",borderTopLeftRadius:28,borderTopRightRadius:28,padding:20,minHeight:330},
  sheetHandle:{width:45,height:5,borderRadius:3,backgroundColor:"#ddd",alignSelf:"center",marginBottom:18},
  commentTitle:{fontSize:21,fontWeight:"900",marginBottom:16},
  comment:{paddingVertical:12,borderBottomWidth:1,borderColor:COLORS.border,fontSize:14},
  commentMeta:{color:COLORS.muted,fontSize:11}
});